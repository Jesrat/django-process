class ProcessException(Exception):
    pass
