from django.apps import AppConfig


class ProcessConfig(AppConfig):
    name = 'process'
